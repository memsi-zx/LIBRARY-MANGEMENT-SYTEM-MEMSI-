<?php
// Include database configuration file
require_once '../config/db.php';

// Call the function to create tables
create_tables($conn);
?>
